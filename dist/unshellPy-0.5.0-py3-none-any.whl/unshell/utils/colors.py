def red(val: str) -> str:
    return f"\x1b[31m{val}\x1b[0m"


def green(val: str) -> str:
    return f"\x1b[32m{val}\x1b[0m"
